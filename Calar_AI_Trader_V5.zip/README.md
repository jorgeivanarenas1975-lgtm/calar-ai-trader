# Calar AI Trader V5

Versión mejorada del analizador.

## Regla principal
- CALL: dos velas verdes consecutivas **cerradas** en temporalidad 1H.
- PUT: dos velas rojas consecutivas **cerradas** en temporalidad 1H.

## Confirmaciones
1. EMA20/EMA50.
2. RSI.
3. Volumen.
4. Dirección de QQQ.
5. Ruptura de confirmación en 5 minutos.
6. Si no se cumplen los filtros, muestra NO OPERAR.

## Opciones
Cuando existe una señal confirmada, intenta sugerir un strike cercano al dinero con 21–45 DTE y liquidez mínima. También muestra break-even aproximado al vencimiento.

## Importante
La aplicación es un sistema de análisis y filtrado, no garantiza resultados ni sustituye la gestión de riesgo. Las primas de opciones dependen también de volatilidad implícita, theta, spread y otros factores.
